-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 29, 2019 at 12:22 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `map`
--

-- --------------------------------------------------------

--
-- Table structure for table `codinates`
--

CREATE TABLE `codinates` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `codinates`
--

INSERT INTO `codinates` (`id`, `name`, `adress`, `lng`, `lat`) VALUES
(2, 'dalalooo', 'daladala', '37.0833', '-1.05'),
(3, 'ungraloo', 'kawangware', '37.0833', '-1.05'),
(5, 'hdjfsjhhdkajhk', 'ncm,zjksfjhshkfge cool staff thats awsome0', '37.08365', '-1.05656'),
(6, 'wertyuiop', 'kamakwa location', '36.9591669', '-0.3920199'),
(7, 'macounty\r\n', '0', '37.0833', '-1.05'),
(15, 'Kisumu county', 'kisumucounty home of kogalo', '0.0917', '34.7680'),
(16, 'Nakuru county', 'conty where we all meet', '0.3031', '36.0800'),
(17, 'kamujulus', '0', '36.96095222345678', '-0.3976947234567890'),
(18, 'Kisumu dala', 'dalaloo', '0.0917', '34.7680');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `codinates`
--
ALTER TABLE `codinates`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `codinates`
--
ALTER TABLE `codinates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
